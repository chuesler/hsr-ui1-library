package comp;

/**
 * Simple listener to catch updates.
 * 
 * @author Ch. Hüsler
 */
public interface UpdateListener {

	public void update();

}
